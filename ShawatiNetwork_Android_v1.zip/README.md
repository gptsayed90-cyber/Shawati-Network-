# Shawati Network Android App — v1

This is the first offline/demo Android project for Shawati Network.

Included:
- Home dashboard
- Balance and earnings cards
- Wallet
- Team
- Profile
- Referral placeholder
- No domain or hosting required for the demo UI

Important:
This package is Android source code, not a compiled APK. A complete APK build requires an Android/Gradle build environment.

Next backend-ready features:
- OTP login
- Real user database
- bKash/Nagad withdrawal
- Referral system
- B/C/D commission
- Admin panel
- Notifications
- Transaction history
