package com.shawatinetwork.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout root, content;

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    TextView title(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(Color.WHITE);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(dp(16), dp(10), dp(16), dp(10));
        return t;
    }

    TextView card(String heading, String value) {
        TextView t = new TextView(this);
        t.setText(heading + "\n" + value);
        t.setTextSize(16);
        t.setTextColor(Color.DKGRAY);
        t.setPadding(dp(18), dp(18), dp(18), dp(18));
        t.setBackgroundColor(Color.rgb(245,248,246));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(10), dp(6), dp(10), dp(6));
        t.setLayoutParams(p);
        return t;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    void base(String pageTitle) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.rgb(11,122,83));
        TextView t = title(pageTitle, 20);
        bar.addView(t, new LinearLayout.LayoutParams(0, dp(60), 1));
        root.addView(bar);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        String[] names = {"Home", "Wallet", "Team", "Profile"};
        for (String n : names) {
            Button x = new Button(this);
            x.setText(n);
            x.setOnClickListener(v -> {
                if (n.equals("Home")) showHome();
                else showPage(n);
            });
            nav.addView(x, new LinearLayout.LayoutParams(0, dp(55), 1));
        }
        root.addView(nav);
        setContentView(root);
    }

    void showHome() {
        base("Shawati Network");
        TextView welcome = new TextView(this);
        welcome.setText("স্বাগতম\nShawati Network");
        welcome.setTextSize(26);
        welcome.setTypeface(null, Typeface.BOLD);
        welcome.setTextColor(Color.rgb(11,122,83));
        welcome.setGravity(Gravity.CENTER);
        welcome.setPadding(0, dp(30), 0, dp(20));
        content.addView(welcome);

        content.addView(card("Available Balance", "৳ 0.00"));
        content.addView(card("Total Earnings", "৳ 0.00"));
        content.addView(card("My Team", "0 Members"));
        content.addView(card("Referral Code", "SHAWATI-0001"));

        Button referral = new Button(this);
        referral.setText("Share Referral");
        referral.setOnClickListener(v -> Toast.makeText(this,
                "Referral feature will connect to backend later.", Toast.LENGTH_SHORT).show());
        content.addView(referral);
    }

    void showPage(String name) {
        base(name);
        if (name.equals("Wallet")) {
            content.addView(card("Wallet Balance", "৳ 0.00"));
            content.addView(card("Withdraw", "bKash / Nagad — Backend pending"));
            content.addView(card("Transaction History", "No transactions yet"));
        } else if (name.equals("Team")) {
            content.addView(card("Direct Members", "0"));
            content.addView(card("Team Members", "0"));
            content.addView(card("Commission", "৳ 0.00"));
        } else {
            content.addView(card("Profile", "User account"));
            content.addView(card("Mobile", "Not connected"));
            content.addView(card("Account Status", "Demo mode"));
        }
    }
}
